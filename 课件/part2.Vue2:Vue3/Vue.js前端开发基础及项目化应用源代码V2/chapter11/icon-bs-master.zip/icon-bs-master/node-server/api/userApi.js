//用户api
//引入router
const router = require('./index.js');
//应用连接池方式
const $sql = require('../dbpool/sqlMap');
const pool = require('../dbpool/pool');
const tools = require('../util/tools');
let {PRIVITE_KEY, EXPIRESD} = require('../util/common');
//cnpm install jsonwebtoken 已安装
const jwt = require('jsonwebtoken')


//登录验证
router.post('/login', (req, res) => {    
    let sql = $sql.user.checkUser;
    let params = req.body;
    pool.query(sql, [params.userName, params.password], (err, result) => {
        if(err) {
            console.log('error');
        }
        if(result.length === 1){            
            let content = { userName: params.userName }; // 加密信息                
            //token = 加密信息 + 密钥 + 过期时间
            let token = jwt.sign(content, PRIVITE_KEY, {
                expiresIn: EXPIRESD // 1小时过期
            });
            tools.jsonWrite(res, {token: token, userName: params.userName, userId: result[0].id});
             
        } else {
            tools.jsonWrite(res, null);
        }       
    })
})

//查询用户信息
router.get('/getAccount', (req, res) => {
    const sql = $sql.user.getUserByName;
    const params = [tools.getUserName(req)]; // req.body    
    pool.query(sql, params, (err, result) => {
        if(err) {
            console.log(err);
        }
        if(result) {                        
            tools.jsonWrite(res, result);
        }
    })
})

//新增用户
router.post('/addUser', (req, res) => {    
    const req_params = req.body
    const arr = [
        req_params.userName,
        req_params.password,
        req_params.email,
        req_params.city,
        req_params.introduce,
        req_params.status
    ]

    const sql_1 = $sql.user.getUserByName;
    const user_name = req_params.userName; // req.body  
    pool.query(sql_1, user_name, (err, result) => {
        if(err) {
            console.log(err);
        }
        if(result.length > 0) {                                    
            let res_params = {
                code: 0,
                message: "用户名已存在"                
            }
            res.send(res_params)
        } else {
            const sql_2 = $sql.user.addUser
            pool.query(sql_2, arr, (err, result) => {
                if(err) {
                    console.log(err)
                }
                if(result) {
                    let res_params = {
                        code: 1,
                        message: "操作成功",
                        data: result
                    }
                    res.send(res_params)
                } else {
                    let res_params = {
                        code: 0,
                        message: "操作失败"
                    }
                    res.send(res_params)
                }
            })
        }
    })
})

//修改用户信息
router.post('/updateUser', (req, res) => {
    const sql = $sql.user.updateUser
    const req_params = req.body
    const arr = [        
        req_params.password,
        req_params.avater,  
        req_params.email,
        req_params.city,
        req_params.introduce,
        req_params.status,
        req_params.id
    ]
    pool.query(sql, arr, (err, result) => {
        if(err) {
            console.log(err)
        }
        if(result) {
            tools.jsonWrite(res, result)
        }
    })
})

module.exports = router