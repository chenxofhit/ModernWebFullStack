/*
*收藏夹api
*/
//引入router
const router = require('./index.js')
//应用连接池方式
const $sql = require('../dbpool/sqlMap')
const pool = require('../dbpool/pool')//引入数据库连接池的模块
const tools = require('../util/tools')

//查询收藏夹信息
router.get('/getFavoritesByUserId', (req, res) => {
    //查询用户id
    const sql = $sql.favorites.getFavoritesByUserId
    const req_params = [tools.getUserName(req)]
    pool.query(sql, req_params, (err, result) => {
        if(err) {
            console.log(err)
        }
        if(result) {            
            let res_params = {
                code:1,
                message: "操作成功",
                data: result
            }
            res.send(res_params)
        } else {
            let res_params = {
                code: 0,
                message: "操作失败"
            }
            res.send(res_params)
        }
    })         
})

//查询指定产品被收藏数
router.get('/getFavorityCountByPids', (req, res) => {
    const sql = $sql.favorites.getFavorityCountByPids
    const req_params = [req.query.productIds]
    pool.query(sql, req_params, (err, result) => {
        if(err){
            console.log(err)
        }
        if(result){
            let res_params = {
                code: 1,
                message: "操作成功",
                data: result
            }
            res.send(res_params)
        } else {
            let res_params = {
                code: 0,
                message: "操作失败"                
            }
            res.send(res_params)
        }
    })
})
//检查当前用户是否收藏该产品
router.get('/checkIsCollect', (req, res) => {
    const sql = $sql.favorites.checkIsCollect
    const req_params = [req.query.productId, req.query.userId]
    pool.query(sql, req_params, (err, result) => {
        if(err){
            console.log(err)
        }        
        if(result){
            let res_params = {
                code: 1,
                message: "操作成功",
                data: result
            }
            res.send(res_params)
        } else {
            let res_params = {
                code: 0,
                message: "操作失败"                
            }
            res.send(res_params)
        }
    })
})

//增加收藏项
router.post('/addFavorites', (req, res) => {
    const sql = $sql.favorites.addFavorites
    const req_params = req.body
    pool.query(sql, [req_params.productId, req_params.userId], (err, result) => {
        if(err){
            console.log(err)
        }
        if(result){
            let res_params = {
                code:1,
                message:"操作成功",
                data:result
            }
            res.send(res_params)
        } else {
            let res_params = {
                code: 0,
                message: "操作失败"
            }
            res.send(res_params)
        }
    })
})

//移除收藏项
router.get('/deleteFavorites', (req, res) => {
    const sql = $sql.favorites.deleteFavorites
    const req_params = [req.query.favoritesId]    
    pool.query(sql, req_params, (err, result) => {
        if(err) {
            console.log(err)
        }

        if(result){
            let res_params = {
              code:1,
              message:"操作成功",
              data:result
            }    
            res.send(res_params)
          }else{
            let res_params = {
              code:0,
              message:"操作失败"
            }    
            res.send(res_params)
          }  
    })
})

module.exports = router