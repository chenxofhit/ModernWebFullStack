//引入router
const router = require('./index.js')
//应用连接池方式
const $sql = require('../dbpool/sqlMap')
const pool = require('../dbpool/pool')
const tool = require('../util/tools')

//查询指定产品点赞数
router.get('/getLikeCountByPids', (req, res) => {
    const sql = $sql.comment.getLikeCountByPids
    const req_params = [req.query.productIds]
    pool.query(sql, req_params, (err, result) => {
        if(err){
            console.log(err)
        }
        if(result) {
            let res_params = {
                code: 1,
                message: "操作成功",
                data: result
            }
            res.send(res_params)
        } else {
            let res_params = {
                code: 0,
                message: "操作失败"
            }
            res.send(res_params)
        }
    })
})
//查询指定产品下载次数
router.get('/getDownCountByPids', (req, res) => {
    const sql = $sql.comment.getDownCountByPids
    const req_params = [req.query.productIds]
    pool.query(sql, req_params, (err, result) => {
        if(err) {
            console.log(err)
        }
        if(result) {            
            let res_params = {
                code: 1,
                message: "操作成功",
                data: result
            }
            res.send(res_params)
        } else {
            let res_params = {
                code: 0,
                message: "操作失败"
            }
            res.send(res_params)
        }
    })
})
//检查用户是否已对当前产品点赞
router.get('/checkIsLike', (req, res) => {
    const sql = $sql.comment.checkIsLike
    const req_params = [tool.getUserName(req), req.query.productId]  
    
    pool.query(sql, req_params, (err, result) =>{
        if(err) {
            console.log(err)
        }
        if(result) {
            let res_params = {
                code: 1,
                message: "操作成功",
                data: result
            }
            res.send(res_params)
        } else {
            let res_params = {
                code: 0,
                message: "操作失败"
            }
            res.send(res_params)
        }
    })
})

//当前用户为指定产品点赞
router.post('/addLikeForProduct', (req, res) => {
    const sql_1 = $sql.comment.getLikeByUidPid
    const req_params_1 = req.body
    
    pool.query(sql_1, [req_params_1.productId, req_params_1.userId], (err_1, result_1) => {         
        if(err_1){
            console.log(err_1)
        } 
        if(result_1.length > 0 && result_1[0].is_like === 0) { // 已有记录，但未点赞，需修改记录                 
            const sql_2 = $sql.comment.updateLikeById
            const req_params_2 = [result_1[0].id]
            pool.query(sql_2, req_params_2, (err_2, result_2) => {
                if(err_2){
                    console.log(err_2)
                }                
                if(result_2) {
                    let res_params = {
                        code: 1,
                        message: "操作成功",
                        data: result_2
                    }
                    res.send(res_params)
                } else {
                    let res_params = {
                        code: 0,
                        message: "操作失败"
                    }
                    res.send(res_params)
                }
            })
        } else {//无该产品点赞或下载记录, 需要新增记录                   
            const sql_3 = $sql.comment.addLikeForProduct            
            pool.query(sql_3, [req_params_1.productId, req_params_1.userId, req_params_1.isLike], (err_3, result_3) => {
                if(err_3) {
                    console.log(err)
                }                
                if(result_3) {
                    let res_params = {
                        code: 1,
                        message: "操作成功",
                        data: result_3
                    }
                    res.send(res_params)
                } else {
                    let res_params = {
                        code: 0,
                        message: "操作失败"
                    }
                    res.send(res_params)
                }
            })
        } 
    })
})

//增加下载次数
router.post('/addDownForProduct', (req, res) => {
    const sql_1 = $sql.comment.getDownByUidPid
    const req_params_1 = req.body
    pool.query(sql_1, [req_params_1.productId, req_params_1.userId], (err_1, result_1) => {
        if(err_1){
            console.log(err_1)
        }
        if(result_1.length>0) {
            const sql_2 = $sql.comment.updateDownCountById
            pool.query(sql_2, [result_1[0].id], (err_2, result_2) => {
                if(err_2){
                    console.log(err_2)
                }
                if(result_2) {
                    let res_params = {
                        code: 1,
                        message: "操作成功",
                        data: result_2
                    }
                    res.send(res_params)
                } else {
                    let res_params = {
                        code: 0,
                        message: "操作失败"
                    }
                    res.send(res_params)
                }
            })
        } else {
           const sql_3 = $sql.comment.addDownForProduct
           pool.query(sql_3, [req_params_1.productId, req_params_1.userId, req_params_1.downTimes], (err_3, result_3) => {
            if(err_3){
                console.log(err_3)
            }
            if(result_3) {
                let res_params = {
                    code: 1,
                    message: "操作成功",
                    data: result_3
                }
                res.send(res_params)
            } else {
                let res_params = {
                    code: 0,
                    message: "操作失败"
                }
                res.send(res_params)
            }
           }) 
        }
    })
})

module.exports = router