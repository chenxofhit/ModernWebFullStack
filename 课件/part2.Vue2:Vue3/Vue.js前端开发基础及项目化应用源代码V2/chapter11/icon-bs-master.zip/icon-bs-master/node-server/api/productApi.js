/*
*产品api
*/
//引入router
const router = require('./index.js')
//应用连接池方式
const $sql = require('../dbpool/sqlMap')
const pool = require('../dbpool/pool')//引入数据库连接池的模块
const tools = require('../util/tools')

const multer = require('multer')

//cnpm install formidable --save
//const formidable = require("formidable")
//cnpm install fs --save
const fs = require("fs");


let jsonWrite = function(res, ret) {
    if(typeof ret === 'undefined') {
        res.json({
            code: 0,
            msg: '操作失败'
        });
    } else {
        res.json({
            code: 1,
            data: ret
        });
    }
}

//查询产品信息列表
router.get('/getAllProduct', (req, res) => {
    const sql = $sql.product.getAllProduct
    const req_params = [] 
    pool.query(sql, req_params, (err, result) => {
        if(err) {
            console.log(err)
        }
        if(result){
            let res_params = {
              code:1,
              message:"操作成功",
              data:result
            }    
            res.send(res_params)
          }else{
            let res_params = {
              code:0,
              message:"操作失败"
            }    
            res.send(res_params)
          }  
    })
})

//查询产品信息列表
router.get('/getProductByCategory', (req, res) => {
    const sql = $sql.product.getProductByCategory
    const req_params = [req.query.category] 
    pool.query(sql, req_params, (err, result) => {
        if(err) {
            console.log(err)
        }
        if(result){
            let res_params = {
              code:1,
              message:"操作成功",
              data:result
            }    
            res.send(res_params)
          }else{
            let res_params = {
              code:0,
              message:"操作失败"
            }    
            res.send(res_params)
          }  
    })
})

//根据产品名称查询产品信息
router.get('/getProductByName', (req, res) => {
    const sql = $sql.product.getProductByName
    const req_params = [req.query.proName]
    pool.query(sql, req_params, (err, result) => {
        if(err) {
            console.log(err)
        }
        if(result) {
            let res_params = {
                code: 1,
                message: "操作成功",
                data: result
            }
            res.send(res_params)
        } else {
            let res_params = {
                code: 0,
                message: "操作失败"
            }
            res.send(res_params)
        }
    })
})

//移除指定产品
router.get('/deleteProduct', (req, res) => {
    const sql = $sql.product.deleteProduct
    const req_params = [req.query.id]     
    pool.query(sql, req_params, (err, result) => {
        if(err) {
            console.log(err)
        }
        if(result){
            let res_params = {
              code:1,
              message:"操作成功",
              data:result
            }    
            res.send(res_params)
          }else{
            let res_params = {
              code:0,
              message:"操作失败"
            }    
            res.send(res_params)
          }  
    })
})

let now = Date.now();
let upload = multer({
	storage: multer.diskStorage({
		//设置文件存储位置
		destination: function(req, file, cb) {			
			//dir就是上传文件存放的目录
			cb(null, "public/images/product");
		},
		//设置文件名称
		filename: function(req, file, cb) {			
			//fileName就是上传文件的文件名
			cb(null, now + file.originalname)
		}
	})
});

//新增产品
router.post('/addProduct', upload.single('file'),  (req, res) => {
    const req_params = req.body
    const sql = $sql.product.addProduct
    //let filePath = '/api/product/getImg?img=' + now + req_params.fileName
    let filePath = now + req_params.fileName
    let  arr = [
        req_params.category, 
        req_params.productName,
        filePath,
        req_params.fileSize,
        req_params.productDesc,
        req_params.userId,
        req_params.createDate
    ]
    pool.query(sql, arr, (err, result) => {
        if(err) {
            console.log(err)
        }
        if(result){
            let res_params = {
              code:1,
              message:"操作成功",
              data:result
            }    
            res.send(res_params)
        }else{
            let res_params = {
              code:0,
              message:"操作失败"
            }    
            res.send(res_params)
        } 
    })
})

// router.post('/uploadImage', upload.single('file'), (req, res) => {
    
//     console.log(req.file)
//     res.json({
//       file: req.file
//     })
// })

router.get('/getImg', function (req, res) {
    let img = req.query.img
    let path = `public/images/product/${img}`;
    const data = fs.readFile(path, function (err, data) {
      if (err) {
        res.send('读取错误');        
      } else {       
        res.send(data);
       
      }
    })
})


module.exports = router