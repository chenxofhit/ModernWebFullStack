let sqlMap = {
    user: {
        addUser:'INSERT INTO user_info (`user_name`, `password`, `email`, `city`,`introduce`,`status`) VALUES (?, ?, ?, ?, ?, ?)',
        updateUser:'UPDATE user_info SET password=?, avater=?, email=?, city=?, introduce=?, status=? WHERE id=?',
        getUserByName:'SELECT * FROM user_info WHERE user_name=?',         
        checkUser: 'SELECT id, user_name from user_info where user_name=? and password=?'              
    },
    product: { 
        addProduct:'INSERT INTO product_info (`category`, `pro_name`, `pro_path`, `pro_size`, `pro_desc`, `user_id`,`create_date`) VALUES (?, ?, ?, ?, ?, ?, ?);',
        deleteProduct:'DELETE FROM product_info WHERE id=?',
        getAllProduct:'SELECT p.id AS id, p.pro_name AS productName, p.pro_path AS originalPath, '
            + 'p.pro_size AS fileSize, p.pro_desc AS proDescribe, '
            + 'p.create_date AS createDate, p.category, u.user_name AS userName FROM product_info p '
            + 'JOIN user_info u ON p.user_id=u.id',        
        getProductByCategory:'SELECT p.id AS id, p.pro_name AS productName, p.pro_path AS originalPath, '
            + 'p.pro_size AS fileSize, p.pro_desc AS proDescribe, '
            + 'p.create_date AS createDate, p.category, u.user_name AS userName FROM product_info p '
            + 'JOIN user_info u ON p.user_id=u.id WHERE p.category=?',
        getProductByName: `SELECT p.id AS id, p.pro_name AS productName, p.pro_path AS originalPath, `
        + `p.pro_size AS fileSize, p.pro_desc AS proDescribe, `
        + `p.create_date AS createDate, p.category, u.user_name AS userName FROM product_info p `
        + `JOIN user_info u ON p.user_id=u.id WHERE p.pro_name like CONCAT('%', ? , '%')`
        
        
        // getAllProduct:'SELECT p.id AS id, p.pro_name AS productName, p.pro_path AS originalPath, '
        //     + 'p.pro_minor AS minorPath, p.pro_size AS fileSize, p.pro_desc AS proDescribe, '
        //     + 'p.create_date AS createDate, p.category, u.user_name AS userName FROM product_info p '
        //     + 'JOIN user_info u ON p.user_id=u.id',        
        // getProductByCategory:'SELECT p.id AS id, p.pro_name AS productName, p.pro_path AS originalPath, '
        //     + 'p.pro_minor AS minorPath, p.pro_size AS fileSize, p.pro_desc AS proDescribe, '
        //     + 'p.create_date AS createDate, p.category, u.user_name AS userName FROM product_info p '
        //     + 'JOIN user_info u ON p.user_id=u.id WHERE p.category=?',
        // getProductByName: `SELECT p.id AS id, p.pro_name AS productName, p.pro_path AS originalPath, `
        // + `p.pro_minor AS minorPath, p.pro_size AS fileSize, p.pro_desc AS proDescribe, `
        // + `p.create_date AS createDate, p.category, u.user_name AS userName FROM product_info p `
        // + `JOIN user_info u ON p.user_id=u.id WHERE p.pro_name like CONCAT('%', ? , '%')`
        
    },
    favorites: {  
        addFavorites: 'INSERT INTO favorites (product_id, user_id) VALUES (?, ?)',
        getFavoritesByUserId: 'SELECT f.id AS id, u.user_name AS userName, ' 
            + 'p.pro_name AS productName, p.pro_path AS originalPath, p.category AS category FROM favorites f '
            + 'JOIN product_info p JOIN user_info u ON f.product_id=p.id AND f.user_id=u.id '
            + 'WHERE f.user_id=(SELECT id FROM user_info WHERE user_name=?)',
        deleteFavorites: 'DELETE FROM favorites WHERE id=?',
        getFavorityCountByPids: `SELECT product_id as id, COUNT(*) as favoriteTimes FROM favorites WHERE product_id in (?) GROUP BY product_id`,
        checkIsCollect: 'SELECT COUNT(*) as count FROM favorites WHERE product_id=? AND user_id=?'      
        // addFavorites: 'INSERT INTO favorites (product_id, user_id) VALUES (?, ?)',
        // getFavoritesByUserId: 'SELECT u.user_name AS userName, ' 
        //     + 'p.pro_name AS productName, p.pro_minor AS productMinor FROM favorites f '
        //     + 'JOIN product_info p JOIN user_info u ON f.product_id=p.id AND f.user_id=u.id '
        //     + 'WHERE f.user_id=(SELECT id FROM user_info WHERE user_name=?)',
        // deleteFavorites: 'DELETE FROM favorites WHERE id=?',
        // getFavorityCountByPids: `SELECT product_id as id, COUNT(*) as favoriteTimes FROM favorites WHERE product_id in (?) GROUP BY product_id`,
        // checkIsCollect: 'SELECT COUNT(*) as count FROM favorites WHERE product_id=? AND user_id=?'

    },
    comment: {
        getLikeCountByPids: `SELECT product_id as id, COUNT(*) as likeTimes FROM comment WHERE is_like=1 AND product_id in (?) GROUP BY product_id`,        
        addLikeForProduct: 'INSERT INTO comment (product_id, user_id, is_like) VALUES (?, ?, ?)',
        checkIsLike: 'SELECT COUNT(*) as count FROM user_info u JOIN comment c ON c.user_id = u.id WHERE u.user_name=? AND c.product_id=? AND c.is_like=1',
        getLikeByUidPid: 'SELECT id, product_id, user_id, is_like FROM comment WHERE product_id=? AND user_id=?',
        updateLikeById: 'UPDATE comment SET is_like=1 WHERE id=?',
        getDownCountByPids: `SELECT product_id as id, SUM(down_times) as downTimes FROM comment WHERE product_id in (?) GROUP BY product_id`,
        getDownByUidPid: 'SELECT id, product_id, user_id, down_times FROM comment WHERE product_id=? AND user_id=?',
        addDownForProduct: 'INSERT INTO comment (product_id, user_id, down_times) VALUES (?, ?, ?)',
        updateDownCountById: 'UPDATE comment SET down_times = down_times + 1 WHERE id=?' 

    }

}

module.exports = sqlMap