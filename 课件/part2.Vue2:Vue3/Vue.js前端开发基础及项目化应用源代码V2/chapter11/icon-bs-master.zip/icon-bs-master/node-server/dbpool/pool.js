//cnpm install mysql
let mysql = require('mysql')
let poolObj = mysql.createPool({
    connectionLimit: 10,
    host: '127.0.0.1',
    database: 'icondb',
    user: 'root',
    password: '123456'
})
/**
 * 
 * @param {*} sql SQL查询语句
 * @param {*} values SQL查询语句参数
 * @param {*} callback 回调函数
 */
function query(sql, values, callback) {
    poolObj.getConnection(function(err, conn){
        if(err) {
            console.log(err)
        }        
        conn.query(sql, values, function(err, results, fields){
            callback(err, results)
        })        
        if(conn) {
            poolObj.releaseConnection(conn)
        }
    })
}

exports.query = query