//node 后端服务器入口
const userApi = require('./api/userApi');
const productApi = require('./api/productApi');
const favoritesApi = require('./api/favoritesApi');
const commentApi = require('./api/commentApi');
let path = require('path');
let cors = require('cors'); 

//cnpm install body-parser 已安装
const bodyParser = require('body-parser');
const express = require('express');
const app = express();

//cnpm install express-jwt 已安装
let expressJWT = require('express-jwt');
let {PRIVITE_KEY} = require('./util/common');

//使用body-parser进行post参数的解析
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: false}));

//访问静态资源目录
app.use(express.static(path.join(__dirname, 'public')));

//跨域后端注册cors，并设置参数，指定origin为客户端地址端口
app.use(cors({  
  origin:['http://localhost:8090'],//origin:['http://localhost:8088'],
  methods:['GET','POST'],
}))

//校验token，获取headers里的Authorization的token，要写在路由加载之前，静态资源之后
app.use(expressJWT({
    secret: PRIVITE_KEY,
    algorithms: ['HS256']
  }).unless({
    path: ['/api/user/login',   
    '/api/user/addUser',  
     '/api/product/getProductByCategory',
     '/api/product/getProductByName',
     '/api/product/getAllProduct',
     '/api/favorites/getFavorityCountByPids',
     '/api/comment/getLikeCountByPids', 
     '/api/comment/getDownCountByPids',    
     '/api/product/getImg'    
  ] //白名单,除了这里写的地址，其他的URL都需要验证
  }));

//注册api路由
app.use('/api/user', userApi);
app.use('/api/favorites', favoritesApi);
app.use('/api/comment', commentApi);
app.use('/api/product', productApi);

//error handler
app.use(function(err, req, res, next) {
    //set locals, only providing error in development
    //res.locals.message = err.message;
    //res.locals.error = req.app.get('env') === 'development' ? err : {};  
    //render the error page
    //res.status(err.status || 500);
    //当客户端请求时发过来的token无效或者过期的时候会触发该错误
    res.render('error');
    if (err.name === 'UnauthorizedError') {
      //这个需要根据自己的业务逻辑来处理（ 具体的err值 请看下面）
      res.status(401).send('无效的token，请重新获取');
    }
    //res.render('error');
  });

// 监听端口
app.listen(3000);
console.log('success listen at port:3000......');