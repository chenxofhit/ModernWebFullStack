let {PRIVITE_KEY} = require('../util/common')
//cnpm i jsonwebtoken
const jwt = require('jsonwebtoken') //引入生成token的依赖

const utilityApi = {   
    getUserName: function(req){ //从token中提取用户名
        let token = req.headers.authorization;   
        token = token.slice(7) //去掉 Bearer及空格，共7个字符
        let userName = ''
        // 同样可验证token合法性，并可以对token进行解码
        //jwt.verify()
        jwt.verify(token,PRIVITE_KEY,function(err,decode){
            if(err) {
                console.log('认证未通过')
            } else {
                userName = decode.userName            
            }       
        })    
        return userName
    },
    jsonWrite: function(res, ret){ //封装为json对象格式
        if(typeof ret == 'undefined') {
            res.json({
                code: 0,
                message: 'failed'
            })
        }else{
            res.json({
                code: 1,
                message: 'success',
                data: ret
            })
        }
    }
}

module.exports = utilityApi
