module.exports = {
    PRIVITE_KEY:"jwt",
    EXPIRESD: 60 * 60 * 1
}