<template>
  <div class="help-content">
      <div class="help-introduce">
        <p>图片资源类别介绍：</p>
        <p>（1）人物类；</p>
        <p>（2）风景类;</p>
        <p>（3）动物类；</p>
        <p>（4）抽象类。</p>
      </div>
      <div class="help-contract">
        <p>联系我们</p>
        <p>电话：020-××××××××</p>
        <p>邮箱：aaa@×××.com</p>
      </div>
  </div>
</template>

<script>
export default {
    name: 'HelpInfo'
}
</script>

<style>
.help-content {
  height: 180vh;
  width: 84vw;
  margin: 0 auto;
}

.help-introduce{
  height: 100vh;
  width: 50vw;
  text-align: left;
  margin: 30px 0 0 20px;
}
.help-contract{
  height: 40vh;
  width: 40vw; 
  text-align: left;
  margin: 30px 0 0 20px;
}

</style>