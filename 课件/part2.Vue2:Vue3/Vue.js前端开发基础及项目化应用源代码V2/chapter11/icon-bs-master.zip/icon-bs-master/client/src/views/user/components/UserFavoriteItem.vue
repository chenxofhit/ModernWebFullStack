<template>
    <div class="page-content-main">
        <el-table :data="favoriteList" style="width: 765px" class="user-favorite-table">
            <el-table-column fixed label="图片" >
                <template #default="scope">
                    <el-image  style="width: 75px; height: 70px" :src="scope.row.imageSrc" alt="" ></el-image>
                 </template>  
            </el-table-column>
            <el-table-column prop="proName" label="图片名称"  />
            <el-table-column prop="category" label="类别"  />
            <el-table-column fixed="right" label="操作">
                <template #default="scope">
                    <el-button type="info" size="small" @click="handleRemove(scope.row)">移除</el-button>                    
                </template>
            </el-table-column>
        </el-table> 
    </div>
</template>
<script>
    import {reactive, toRefs, onBeforeMount, onMounted} from 'vue'
    import { request } from '@/axios'
    import { ElMessage } from 'element-plus'
    import { useStore } from 'vuex'
    export default {
        name: 'UserFavorite',
        setup() {
            const store = useStore()
            const view_data = reactive({
                favoriteTable: [],
                // [{
                //     imageSrc: 'image1',
                //     name: 'Tom',
                //     category: '2016-05-02'
                    
                // },
                // {
                //     imageSrc: 'image',
                //     name: 'Tom',
                //     category: '2016-05-02'
                    
                // },
                // {
                //     imageSrc: 'image',
                //     name: 'Tom',
                //     category: '2016-05-02'
                    
                // },
                // {
                //     imageSrc: 'image',
                //     name: 'Tom',
                //     category: '2016-05-02'
                    
                    
                // }],
                favorite:{
                    id:'',
                    imageSrc:'',
                    proName:'',
                    category:''
                },
                favoriteList:[]
            })
            const getFavoriteList = async() => {  
                store.dispatch('favorites/getFavorites')
                .then(res => {
                    if(res.code === 1) {
                        //更新收藏产品的数量                    
                        const store_favorites = store.getters['favorites/favoritesList']  
                        store.commit('user/SET_FAVORITE_COUNT', store_favorites.length) 
                        view_data.favoriteList = store_favorites
                    }
                })
           
            }

            onMounted(() => {                
                getFavoriteList()                
            })

            const handleRemove = async(row) => {
                const data_favorite = await request({
                    url:'/api/favorites/deleteFavorites',
                    method:'get',
                    params:{favoritesId: row.id}
                })                
                let msg = ''
                msg = (data_favorite.affectedRows === 1) ? '移除成功' : '移除失败'
                ElMessage({
                    type: 'success',
                    message: msg
                })

                //刷新收藏夹
                getFavoriteList()
            }
            const handleDown = () => {
                console.log("handle down....")
            }

            return {                
                ...toRefs(view_data),
                handleDown,
                handleRemove,
                getFavoriteList
            }
        }
    }
</script>
<style>
    .page-content-main{
        width: 765px;
        height: auto;
        background-color: rgb(107, 206, 156); 
        margin: 20px 10px 20px 20px;
        border:rgb(215, 215, 215) solid 1px;
        border-radius: 5px;
        
    }
    .user-favorite-table {
        margin-left: 0px;
        margin-top: 0px;
        margin-right: 0px;
    }
</style>