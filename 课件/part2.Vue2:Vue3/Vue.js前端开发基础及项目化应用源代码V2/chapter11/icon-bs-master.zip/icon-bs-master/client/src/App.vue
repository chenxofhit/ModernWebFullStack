<template>
  <div id="appDiv">   
    <router-view v-if="isRouterAlive"> </router-view>
  </div>
</template>

<script>
  import {provide, nextTick, ref} from 'vue'
  export default {
    name:'App',
    setup() { 
      const isRouterAlive  = ref(true)    
      const reload = () => { 
        isRouterAlive.value = false //先隐藏组件
        nextTick(() => { //数据更新后，再显示组件
          isRouterAlive.value = true 
        })
      }
      //向子组件提供reload
      provide("reload", reload)
      return {        
        isRouterAlive
      }
    }
  }
</script>

<style>
 @import url("./assets/icons/remixicon.css");
#app {
  font-family: Avenir, microsoft yahei, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #1b1919; /*页面上字体颜色 */
  font-weight: 400;
  
} 

#nav {
  padding: 30px;
}

#nav a {
  font-weight: bold;
  color: #2c3e50;
}

#nav a.router-link-exact-active {
  color: #42b983;
}
</style>
