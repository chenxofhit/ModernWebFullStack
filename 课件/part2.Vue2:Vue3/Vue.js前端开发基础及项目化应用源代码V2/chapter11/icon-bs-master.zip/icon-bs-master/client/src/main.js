import { createApp } from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import ElementPlus from 'element-plus'
import 'element-plus/dist/index.css'
import SysText from '@/components/common/SysText.vue'
import SysIcon from '@/components/common/SysIcon.vue'
import http from '@/utils/global.js'

const app = createApp(App)
//全局变量定义与使用方式二：使用app.config.globalProperties.$category, getCurrentInstance
//app.config.globalProperties.$category = ['花卉', '绿植', '其他']
//全局变量定义与使用方式一： 使用provide/inject
app.provide('$category', ['花卉','颜色','节气','脸谱','手作'])
//挂载为全局变量
app.provide('$http', http)
//全局注册插件
app.use(store)
app.use(router)
app.use(ElementPlus)
//注册全局组件
app.component('sys-text', SysText)
app.component('sys-icon', SysIcon)
//挂载
app.mount('#app')

