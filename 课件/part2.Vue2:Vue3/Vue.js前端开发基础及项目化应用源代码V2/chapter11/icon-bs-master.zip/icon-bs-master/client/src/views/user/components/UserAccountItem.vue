<template>
    <div class="page-content-main">
        <el-form
            ref="accountFormRef"
            :model="accountForm"
            :rules="rules"
            label-width="120px"
            class="user-accountForm"
            :size="formSize"
        >
            <!-- <el-form-item label="头 像" prop="avater">
                <el-avatar shape="circle" :size="100" :fit="fit" :src="accountForm.avater"></el-avatar>
            </el-form-item> -->
            <el-form-item label="用户名" prop="userName">
                <el-input v-model="accountForm.userName"></el-input>
            </el-form-item>
            <el-form-item label="密  码" prop="password">
                <el-input v-model="accountForm.password"></el-input>
            </el-form-item>
            <el-form-item label="邮  箱" prop="email">
                <el-input v-model="accountForm.email"></el-input>
            </el-form-item>                
            <el-form-item label="城市" prop="city">
                <el-input v-model="accountForm.city"></el-input>
            </el-form-item>
            <el-form-item label="帐户状态" prop="status">
                <el-switch v-model="accountForm.status"></el-switch><el-form-item label="公开/不公开"></el-form-item>
            </el-form-item>                
            <el-form-item label="个人简介" prop="introduce">
                <el-input v-model="accountForm.introduce" type="textarea"></el-input>
            </el-form-item>
            <el-form-item>
                <el-button type="primary" @click="toSubmitForm">提交</el-button>                
            </el-form-item>
        </el-form>
    </div>
</template>
<script>
    import {toRefs, reactive, ref, onBeforeMount} from 'vue'
    import {request} from '@/axios'
    import { ElMessage } from 'element-plus'
    export default {
        name: 'UserAccount',
        setup() {   
            const accountFormRef = ref(null)         
            const formSize = ref('default')
            const fit = ref('fill')            
            const view_data = reactive({
                accountForm:{
                    id:'',     
                    //avater:require('../../assets/img/girl_2.jpg'),
                    userName: '',
                    password: '',
                    email: '',
                    status: false,
                    city: '',
                    introduce:''
                }                                
            })

            const rules = reactive({
                userName: [{
                    required: true,
                    message: 'Please input user name',
                    trigger: 'blur',
                },
                {
                    min: 3,
                    max: 12,
                    message: 'Length should be 3 to 12',
                    trigger: 'blur',
                }],
                password: {
                    required: true,
                    message: 'Please input password',
                    trigger: 'blur',
                },
                email: {
                    required: true,
                    message: 'Please input email',
                    trigger: 'blur',
                },
                city: {
                    required: true,
                    message: 'Please select city',
                    trigger: 'blur',
                },
                introduce: {
                    required: true,
                    message: 'Please input introduce',
                    trigger: 'blur',
                }
            })

            onBeforeMount(() => {
                getAccount()
            })            

            const getAccount = async() => {
                const data = await request({url:'/api/user/getAccount', method:'get'})
                if(data){  
                    view_data.accountForm.id = data[0].id                  
                    //accountForm.avater = require('../../assets/img/' + data[0].avater)
                    view_data.accountForm.userName = data[0].user_name
                    view_data.accountForm.password = ""
                    view_data.accountForm.email = data[0].email
                    view_data.accountForm.city = data[0].city
                    if(data[0].status === 0){ 
                        view_data.accountForm.status = false 
                    } else if(data[0].status === 1) {
                        view_data.accountForm.status = true
                    }
                    view_data.accountForm.introduce = data[0].introduce                     
                }
            }

            const toSubmitForm = async() => {                
                let isValide = false
                //方式一：getCurrentInstance().refs.accountFormRef.validate()
                //方式二：推荐   accountFormRef.value 即 accountFormRes元素，可以直接使用form表单的方法和属性，事件
                await (accountFormRef.value).validate((valide) => {
                    if(valide){
                        isValide = true
                    } else {
                        console.log('表单数据无效')
                    }
                })
                if(isValide) {
                    let account = Object.assign({}, view_data.accountForm)    
                    //account.avater = 'girl_2.jpg'     //需要处理字符串            
                    account.status = account.status ? 1 : 0               
                    const data = await request({url:'/api/user/updateUser', data: account, method: 'post'}) 
                    const msg = data.affectedRows === 1 ? '修改成功':'修改失败'                    
                    ElMessage({
                        type: 'info',
                        message: msg
                    }) 
                }
            }   
            
            // const toResetForm = () => {
            //     (accountFormRef.value).resetFields();
            // }

            return { 
                accountFormRef,              
                fit,
                formSize,                
                ...toRefs(view_data),
                rules,
                toSubmitForm,                
                getAccount
                
            }
        }
    }
    
</script>
<style>
    .page-content-main{
        width: 765px;
        height: auto;
        background-color: rgb(107, 206, 156); 
        margin: 20px 0px 20px 0px;
        border:rgb(75, 45, 45) solid 1px;
        border-radius: 5px;
        
    }
    .user-accountForm {
        width: 760px;
        height: 500px;
        margin-top: 20px;
        margin-left: -20px;
    }
</style>