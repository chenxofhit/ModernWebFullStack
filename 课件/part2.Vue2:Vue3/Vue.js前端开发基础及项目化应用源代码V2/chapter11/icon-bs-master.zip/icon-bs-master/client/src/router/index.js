import { createRouter, createWebHashHistory, createWebHistory } from 'vue-router'
import { ElMessage } from 'element-plus'

const childRoutes = [
  {
    path: '/default',
    name: 'default',
    component: () => import('../views/default/Default.vue')
  },  
  {
    path: '/product',
    name: 'product',
    component: () => import('../views/product/ProductList.vue')
  },  
  {
    path: '/user',
    name: 'user',
    component: () => import('../views/user/UserInfo.vue')
  },
  {
    path: '/help',
    name: 'help',
    component: () => import('../views/help/HelpInfo.vue')
  }
]

const routes = [  
  {
    path: '/',
    name: 'Home',
    component: () => import('../views/Home.vue'),
    children: childRoutes
  }
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),//history: createWebHashHistory(process.env.BASE_URL),
  routes
})

router.beforeEach((to, from, next) => {  
  let token = sessionStorage.getItem('token')  // 从storge获得的token值类型为字符串
  //console.log(token)
  if(to.path === '/default' || to.path === '/help' || to.path === '/product') {
    next()
  } else {
    if(token === null ||token === 'undefined' || token === '' ){    
      ElMessage({
        type:'warning',
        message: '请先登录',
        duration: 2000
      })
      if(from.path != '/default') {
        router.push({name: 'default'})        
      }
    } else {
      next()
    } 
  }
})

export default router
