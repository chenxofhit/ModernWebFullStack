<template>
    <div class="page-header">                
    </div>    
    <div class="page-default">
        <div class="default-search" >
            <el-input v-model="keyword" placeholder="Please input">
                <template #append><i class="ri-search-2-line" @click="toSearch"></i></template>
            </el-input>
        </div>
        <div class="fade-window">
            <img class="fade-arrow" src="../../assets/img/arrow-left-s-line.png" @click="toPrev"/>                
            <!-- <transition-group name="fade"> -->
                <div v-for="(item, index) in imgPath" :key="index">
                    <img class="fade-img" v-show="currentIndex==index" :src="item"/>
                </div>                    
            <!-- </transition-group>                 -->
            <img class="fade-arrow" src="../../assets/img/arrow-right-s-line.png" @click="toNext"/>
        </div>
        <div class="default-introduce">
            <div class="default-introduce-text">
                <div class="default-introduce-text-title" >海量图片</div>
                <div class="default-introduce-text-content" >100万张图片素材，包括高清图片、矢量图标等，供用户免费下载，可用于网站界面设计、PPT制作等方面。</div>
                <div class="default-introduce-text-title" >使用方法</div>
                <div class="default-introduce-text-content" >可直接下载不同格式的图片，如png、jpg、svb，支持在线调整图片尺寸、颜色，也可作为原创图片的创作元素，从而满足用户不同场景下的需要。</div>
                <div class="default-introduce-text-title" >合作伙伴</div>
                <div class="default-introduce-text-content" >本站与多个商家、平台建立了紧密的战略合作关系，共享资源，可以为用户提供更为丰富的在线资源。</div>
            </div>
            <img class="default-introduce-image" src="../../assets/img/active.jpg" />            
        </div>                       
    </div>        
</template>
<script>
    import { reactive, toRefs, onBeforeMount, ref } from 'vue' 
    import { request } from '@/axios'
    import { useStore } from 'vuex'
    import { useRouter } from 'vue-router'
    import { ElMessage } from 'element-plus'
    //全局变量定义与使用方式一： 使用provide/inject
    import { inject } from 'vue'
    //全局变量定义与使用方式二：使用app.config.globalProperties.$category, getCurrentInstance
    import { getCurrentInstance } from 'vue'    
    export default {
        name:'Default',
        setup() {
            const store = useStore() 
            const router = useRouter()  
            //全局变量定义与使用方式一： 使用provide/inject
            const cate_array = inject('$category')
            //全局变量定义与使用方式二：使用app.config.globalProperties.$category, getCurrentInstance
            //const internalInstance = getCurrentInstance()      
            /**轮播图**/
            const view_data = reactive({
                imgPath:[],
                bannerImages:[
                   {imgSrc: "banner1.jpg"},
                   {imgSrc: "banner2.jpg"},
                   {imgSrc: "banner3.jpg"},
                   {imgSrc: "banner4.jpg"},
                   {imgSrc: "banner5.jpg"},
                   {imgSrc: "banner6.jpg"} 
                ],
                currentIndex: 0,            
                animateTime: 3000
            })              
            //设置轮播图路径
            const initImagePath = () => { 
                for(var i=0; i<view_data.bannerImages.length; i++) {
                    //require动态拼接导入图片访问路径
                    view_data.imgPath.push(require('../../assets/img/' + view_data.bannerImages[i].imgSrc))
                 }
            }
            //定时器
            const setTimer = () => {
                setInterval(autoPlay, view_data.animateTime)
            }
            //自动轮播
            const autoPlay = () => {
                view_data.currentIndex++
                if(view_data.currentIndex == view_data.imgPath.length) {
                   view_data.currentIndex = 0
                }
            }
            //手动播放前一个图片
            const toPrev = () => {
                view_data.currentIndex--
                if(view_data.currentIndex < 0) view_data.currentIndex = view_data.imgPath.length - 1
            }
            //手动播放后一个图片
            const toNext = () => {
                view_data.currentIndex++
                if(view_data.currentIndex > view_data.imgPath.length - 1) view_data.currentIndex = 0
            }

            //挂载前处理：导入图片路径，启动计时器 
            onBeforeMount(() => {
                initImagePath()
                setTimer()                 
            })

            /**图片搜索**/
            const keyword = ref('')
            const toSearch = async () =>{
                const data = await request({
                    url: '/api/product/getProductByName', 
                    params: {proName: keyword.value}, 
                    method: 'get'
                })
                let msg = ''
                if(data === undefined || data.length == 0) {
                    msg = '无符合条件的图片'
                    ElMessage({
                        type: 'info',
                        message: msg
                    })  
                } else {
                    store.commit('product/SET_IS_SEARCH', true)
                    store.commit('product/SET_PRODUCT_BASIC_LIST', data)
                    //全局变量定义与使用方式二：使用app.config.globalProperties.$category, getCurrentInstance
                    //const cate_array = internalInstance.appContext.config.globalProperties.$category
                    let flower_cate = data.find(u => u.category == cate_array[0])
                    let plant_cate = data.find(u => u.category == cate_array[1])
                    let other_cate = data.find(u => u.category == cate_array[2])
                    
                    msg = '返回结果' + data.length + '条，包含类别：'
                    if (flower_cate) {
                        msg = msg + cate_array[0]
                    }
                    if(plant_cate) {
                        msg = msg + "," + cate_array[1]
                    }
                    if(other_cate) {
                        msg = msg + "," + cate_array[2]
                    }
                    ElMessage({
                        type: 'info',
                        message: msg
                    }) 
                    router.push({name: 'product'})                                        
                } 
            }  

            return {
                //将view_data解构（仍具响应性）,模板中可直接使用view_data中属性，如直接使用keyword
                ...toRefs(view_data),
                initImagePath,
                autoPlay,
                setTimer,
                toPrev,
                toNext,
                keyword,
                toSearch                
            }
        }
    }
</script>

<style>
    /*2*/
    .page-header{
        width: 100vw;
        height: 14vh;
        background-color: rgb(218, 116, 32);
        display: flex;
        align-items: flex-end; 
        justify-content: space-between;                                                                 
    }    
    
    /*3*/
    .page-default{
        width: 100vw;
        height: 158vh;
        /* background-color: aquamarine; */
        margin: 30px 0px 0px 0px;
        display: flex;        
        flex-wrap: wrap;  
        justify-content: center;       
    }
    .default-search {
        height: 60px;
        width: 820px;
        /* background-color: rgb(218, 32, 63); */
        line-height: 60px;        
        text-align: center;   
        margin-top: 40px;    
    }
          
    .fade-window {
        width: 1100px;
        height: 200px;
        display: flex;
        flex-direction: row;
        align-items: center;
    }

    .fade-img {
        width: 1020px;
        height: 200px;
    }
    .fade-arrow{
        width: 40px;
        height: 50px;        
    }    

    /* .fade-enter-active{
        transition: all 0.5s
    }
    .fade-leave-active{
        transition: all 0.5s 
    }
    .fade-enter{
        opacity: 0;
        transform: translateX(100%)
    }
    .fade-leave-to {
        opacity: 0;
        transform: translateX(-100%)
    } */
    
    .default-introduce {
        width: 1020px;
        height: 360px;
        display: flex;
        justify-content: space-between;
        flex-wrap: wrap;
    }
    .default-introduce-text {
        width: 460px;
        height: 360px;
        background-color: rgb(107, 206, 156); 
        text-align: left;
        padding-left: 20px;
        margin-right: 40px;
        
    }
    .default-introduce-text-title {        
        font-size: 18px;
        font-weight:600;
        margin-bottom: 10px;
        margin-top:20px;
        
    }
    .default-introduce-text-content {
        font-size: 14px;
        margin-bottom: 40px;
        
    }
    .default-introduce-image{
        width: 500px;
        height: 360px;
        /* background-color: rgb(230, 106, 127);  */
    }
   
</style>