import {request} from '@/axios'
import http from './../../utils/global.js' //引入全局变量
const SET_FAVORITES = 'SET_FAVORITES'

const favorites = {
    namespaced: true,
    state: {
        favorites: []
    },
    getters: {
        favoritesList: state => state.favorites
    },
    mutations: {
        [SET_FAVORITES] (state, favorites) {
            state.favorites = favorites
        }
    },
    actions: {
        getFavorites({commit}) {                   
            return new Promise((resolve,reject) => {                
                request({
                    url: '/api/favorites/getFavoritesByUserId',                     
                    method: 'get'                   
                }).then(res => {
                    let favoritesList = []                     
                    favoritesList = res.map(u => {
                        return {
                            id: u.id,   // favorite id
                            //imageSrc: '/api/product/getImg?img=' + u.originalPath,
                            //此处非axios请求，需要使用后端请求地址http:127.0.0.1:3000
                            imageSrc: http + '/api/product/getImg?img=' + u.originalPath,
                            proName: u.productName,
                            category: u.category
                        }
                    })                    
                    if (favoritesList.length > 0) {
                        commit('SET_FAVORITES', favoritesList)                    
                    }                   
                    resolve({
                        code: 1,
                        message: '成功获取收藏夹'
                    })
                }).catch(err => {                    
                    reject(err)
                })                
            }) 
        }
    }
}

export default favorites