const SET_FAVORITE_COUNT = 'SET_FAVORITE_COUNT'

const user = {
    namespaced: true,
    state: {     
        favoriteCount: -1
    },
    getters:{
        favoriteCount: state => state.favoriteCount
    },
    mutations: {
        [SET_FAVORITE_COUNT](state, favoriteCount){
            state.favoriteCount = favoriteCount
        }
    }
}

export default user