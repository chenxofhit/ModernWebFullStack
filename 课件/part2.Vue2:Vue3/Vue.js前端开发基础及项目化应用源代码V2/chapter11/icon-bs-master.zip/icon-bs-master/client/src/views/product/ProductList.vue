<template>
    <div class="page-header">
        <div class="nav-child">
            <ul class="nav-child-ul" >               
                <li class="menu_product_item" v-for="(item, index) in category_list" :key="index" @click="getProductByCate(item)">{{item}}</li>                  
            </ul>
        </div>        
        <div class="search">
            <el-input v-model="keyword" placeholder="请输入查询条件">
                <template #append><i class="ri-search-2-line" @click="toSearch"></i></template>
            </el-input>
        </div>
    </div>
    <div class="page-content">
        <div class="page-product-list">            
            <div class="item-card item-font" v-for="(item, index) in curproductList" :key="index">
                <div class="item-image">
                    <img class="item-image"  :src="item.originalPath" />
                    <span>
                        <div class="mask">
                            <img class="item-image-mask-icon" src="../../assets/img/favorite.png" @click= "toCollect(item)" />
                            <img class="item-image-mask-icon" src="../../assets/img/like.png" @click= "toGiveLike(item)" />                            
                            <img class="item-image-mask-icon" src="../../assets/img/download.png" @click= 'toDownLoad(item)' />
                        </div>                         
                    </span>
                </div>                    
                <div class="item-text-top">                        
                    <span class="item-text-name">{{item.proName}}</span>                         
                </div>                                                    
                <div class="item-text-bottom">                  
                    <span class="item-text-icon-avatar"><i class="ri-user-line"></i></span><span class="item-text-remark-user">{{item.createUserName}}</span>                       
                    <span class="item-text-space"></span>
                    <span class="item-text-icon-like" ><i class="ri-star-half-fill"></i></span><span class="item-text-remark-like">{{item.favouriteNum}}</span>
                    <span class="item-text-icon-like" ><i class="ri-heart-2-fill"></i></span><span class="item-text-remark-like">{{item.likeNum}}</span>  
                    <span class="item-text-icon-like" ><i class="ri-arrow-down-circle-fill"></i></span><span class="item-text-remark-like">{{item.downNum}}</span>                      
                </div>
            </div>                      
        </div>
        
        <div class="page-more">
           <!--分页子组件-->
            <el-pagination 
                background layout="prev, pager, next" 
                :total=itemTotal
                :page-size="6"
                :current-page=curPage
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange">
            </el-pagination>
        </div>   
    </div>
</template>
<script>
    import { reactive, toRefs, onBeforeMount, ref, onMounted } from 'vue'
    import { useStore } from 'vuex'
    import { request } from '@/axios'
    import { useRouter } from 'vue-router'
    //全局变量定义与使用方式一： 使用provide/inject
    import { inject } from 'vue'
    import { ElMessage } from 'element-plus'
    import { Plus, UploadRawFile, UploadFile, FormInstance, Action } from '@element-plus/icons-vue'
    
    export default{
        components:{
            Plus
        },
        setup(){
            const store = useStore()  
            const router = useRouter()  
            const uploadFile = ref()    
            const view_data = reactive({   
                product:{
                    id: 0, 
                    category:'', 
                    proName:'', 
                    originalPath: '', 
                   // minorPath:'',
                    fileSize:0,
                    proDesc:'',
                    createDate:'',
                    createUserName:'', 
                    favouriteNum: 0, 
                    likeNum: 0,
                    downNum: 0
                },           
                productList:[], //中间数据，用于存储查询返回结果
                productListByCate:[], //用于存储按类别查询的结果
                curproductList: [],                
                pageSize: 6, 
                itemTotal: 0,
                curPage: 1,
                category_list: [],
                keyword: '' 
            })
            
            //全局变量定义与使用方式一： 使用provide/inject
            view_data.category_list = inject('$category')
                      
            //获取商品信息列表
            const getProductList = async() => {                           
                //从store读取查询结果，若有，则直接显示查询结果，若无，则读取所有商品信息 
                let picList = store.getters['product/productBasicList']
                if(!picList || picList.length <= 0) {           
                    console.log('db view_data....')
                    picList = await request({
                        url: '/api/product/getAllProduct',
                        method:'get'
                    })
                    if(picList) {
                        store.commit('product/SET_PRODUCT_BASIC_LIST', picList)        
                    }   
                }
                
                //更新图片状态
                setProductStatus(view_data.category_list[0])    
            }
                                    
            //点赞处理            
            const toGiveLike = async(item) => {
                const token = sessionStorage.getItem("token")
                if(token === 'undefined' || token === null || token === ''){
                    ElMessage({
                        type: 'warning',
                        message: '请先登录',
                        duration: 2000
                    })                    
                    router.push({name: 'default'})    
                } else {
                    //查询当前用户是否已对该产品点赞，如果有，则不再处理
                    //如果没有，需要返回当前用户id
                    const data_count = await request({
                        url:'/api/comment/checkIsLike',
                        method: 'get',
                        params:{productId: item.id}
                    })
                    let msg = ''
                    if(data_count[0].count <= 0) { 
                        const userId = sessionStorage.getItem("userId") 
                        const data_like = await request({
                            url:'/api/comment/addLikeForProduct',
                            method:'post',
                            data:{productId: item.id, userId: userId, isLike: 1}
                        })
                        msg = (data_like.affectedRows === 1) ? '点赞成功' : '点赞失败'
                        ElMessage({
                            type: 'success',
                            message: msg
                        })
                        
                        //更新图片状态
                        setProductStatus(item.category) 
                    } else {
                        msg = '你已点赞'
                        ElMessage({
                            type: 'success',
                            message: msg
                        })
                    }
                }                    
            }
            //实现图片下载
            const handlerDownload = function(imgsrc, name){                
                //下载图片地址和图片名
                var image = new Image()
                // 解决跨域 Canvas 污染问题
                //image.setAttribute("crossOrigin", "anonymous");
                image.src = imgsrc
                image.onload = function() {
                    let canvas = document.createElement("canvas")
                    canvas.width = image.width
                    canvas.height = image.height
                    let context = canvas.getContext("2d")
                    context.drawImage(image, 0, 0, image.width, image.height)
                    let url = canvas.toDataURL("image/png"); //得到图片的base64编码数据
                    let a = document.createElement("a") // 生成一个a元素
                    let event = new MouseEvent("click")// 创建一个单击事件
                    a.download = name || "photo" // 设置图片名称
                    a.href = url //将生成的URL设置为a.href属性
                    a.dispatchEvent(event)// 触发a的单击事件
                }
                
            }
            //下载处理
            const toDownLoad = async(item) => {
                const token = sessionStorage.getItem("token")
                if(token === 'undefined' || token === null || token === ''){
                    ElMessage({
                        type: 'warning',
                        message: '请先登录',
                        duration: 2000
                    })                    
                    router.push({name: 'default'})                       
                } else {
                    //下载处理                
                    handlerDownload(item.originalPath, 'pic')

                    //更新下载次数
                    const userId = sessionStorage.getItem("userId")
                    const data_down = await request({
                        url:'/api/comment/addDownForProduct',
                        method: 'post',
                        data: {productId: item.id, userId: userId, downTimes:1}
                    })
                    let msg = ''
                    msg = (data_down.affectedRows === 1) ? '下载操作成功' : '下载操作失败'
                    ElMessage({
                            type: 'success',
                            message: msg
                        })
                    if(data_down.affectedRows === 1) {
                        setProductStatus(item.category)      //更新界面上图片下载次数               
                    }
                }
            }
            //收藏处理
            const toCollect = async(item) => {  
                const token = sessionStorage.getItem("token")
                if(token === 'undefined' || token === null || token === ''){
                    ElMessage({
                        type: 'warning',
                        message: '请先登录',
                        duration: 2000
                    })                    
                    router.push({name: 'default'})    
                } else {
                    const userId = sessionStorage.getItem("userId")
                    const data_check = await request({
                        url:'/api/favorites/checkIsCollect',
                        method: 'get',
                        params: {productId: item.id, userId: userId}
                    })
                    let msg = ''
                    if(data_check[0].count <= 0) {
                        const data_collect = await request({
                            url:'/api/favorites/addFavorites',
                            method: 'post',
                            data: {productId: item.id, userId: userId}
                        })                    
                        msg = (data_collect.affectedRows === 1) ? '收藏成功' : '收藏失败'
                        ElMessage({
                                type: 'success',
                                message: msg
                            })
                        if(data_collect.affectedRows === 1) {                             
                            //更新用户的收藏数量                    
                            let count = store.getters['user/favoriteCount']
                            count = count + 1
                            store.commit('user/SET_FAVORITE_COUNT', count)
                            //更新图片状态
                            setProductStatus(item.category)
                        }                        
                    } else {
                        msg = '你已收藏'
                        ElMessage({
                            type: 'success',
                            message: msg
                        })
                    }
                    
                }                
            }

            //获取图片的点赞、下载、收藏次数，更新图片状态
            const setProductStatus = async(category) => {                
                let productBasicList = store.getters['product/productBasicList']
                let ids = []                      
                productBasicList.map(u => {  
                    ids.push(u.id)
                })
                //获取产品对应的被收藏次数
                const favorite_count_data =  await request({
                    url: '/api/favorites/getFavorityCountByPids', 
                    method: 'get',
                    params: {productIds: ids}
                })
                //获取产品对应的被点赞次数
                const like_count_data = await request({
                    url:'/api/comment/getLikeCountByPids',
                    method:'get',
                    params:{productIds: ids}
                })  
                //获取产品被下载的次数
                const down_count_data = await request({
                    url: '/api/comment/getDownCountByPids',
                    method: 'get',
                    params: {productIds: ids}
                })

                view_data.productList = productBasicList.map(u => {                     
                    const f_data = favorite_count_data.find(p => {
                        return p.id===u.id
                    })  
                    let f_times = 0
                    if(f_data) {
                        f_times = f_data.favoriteTimes
                    }                  
                    const l_data = like_count_data.find(p => {
                        return p.id === u.id
                    })
                    let l_times = 0
                    if(l_data) {
                        l_times = l_data.likeTimes
                    }                    
                    const d_data = down_count_data.find(p => {                        
                        return p.id == u.id
                    })
                    let d_times = 0
                    if(d_data) {
                        d_times = d_data.downTimes
                    }
                    return {
                        id: u.id, 
                        category: u.category, 
                        proName: u.productName, 
                        originalPath:u.originalPath, 
                        fileSize: u.fileSize,
                        proDesc: u.proDescribe,
                        createDate: u.createDate,
                        createUserName: u.userName,                             
                        favouriteNum: f_times, 
                        likeNum: l_times,
                        downNum: d_times
                    }
                }) 
           
                getProductByCate(category) 
            }
            //注入变量$http
            const http = inject('$http')
            //从商品信息列表中析取指定分类商品
            const getProductByCate = (category) => {                
                view_data.productListByCate = []               
                if(view_data.productList && view_data.productList.length > 0){
                    view_data.productList.forEach((u, index) => {
                        if(u.category === category) {
                            let pro = {}
                            pro.id = u.id, 
                            pro.category = u.category, 
                            pro.proName = u.proName, 
                            //此处非axios请求，需要使用后端请求地址http:127.0.0.1:3000
                            pro.originalPath = http + '/api/product/getImg?img=' + u.originalPath, //获得图片地址
                            pro.fileSize = u.fileSize,
                            pro.proDesc = u.proDesc,
                            pro.createDate = u.createDate,
                            pro.createUserName = u.createUserName,                             
                            pro.favouriteNum = u.favouriteNum, 
                            pro.likeNum = u.likeNum
                            pro.downNum = u.downNum

                            view_data.productListByCate.push(pro)
                        }
                    })
                } 
                
                view_data.itemTotal = view_data.productListByCate.length  
                createCurGoodList(view_data.curPage, view_data.pageSize)       
            }

            const toSearch = async() => {
                const data = await request({
                    url: '/api/product/getProductByName', 
                    params: {proName: view_data.keyword}, 
                    method: 'get'
                })
                let msg = ''
                if(data === undefined || data.length == 0) {
                    msg = '无符合条件的图片'
                    ElMessage({
                        type: 'info',
                        message: msg
                    })  
                } else {
                    store.commit('product/SET_PRODUCT_BASIC_LIST', data)
                    //全局变量定义与使用方式二：使用app.config.globalProperties.$category, getCurrentInstance                   
                    let flower_cate = data.find(u => u.category == view_data.category_list[0])
                    let plant_cate = data.find(u => u.category == view_data.category_list[1])
                    let other_cate = data.find(u => u.category == view_data.category_list[2])
                    
                    msg = '返回结果' + data.length + '条，包含类别：'
                    if (flower_cate) {
                        msg = msg + view_data.category_list[0]
                    }
                    if(plant_cate) {
                        msg = msg + "," + view_data.category_list[1]
                    }
                    if(other_cate) {
                        msg = msg + "," + view_data.category_list[2]
                    }
                    ElMessage({
                        type: 'info',
                        message: msg
                    }) 
                    //更新图片状态
                    setProductStatus(view_data.category_list[0])                                          
                } 
            }
      
            onBeforeMount(() => {                               
                getProductList()                
            })

           
            const handleSizeChange = (p_size) => { //p_size是组件提供的当前每页条数     
                view_data.pageSize = p_size
                createCurGoodList(1, p_size)  
            }
            const handleCurrentChange = (c_page) => { //c_page是组件提供的当前页码
                createCurGoodList(c_page, view_data.pageSize)  
            }  
            const createCurGoodList = (cur_page, page_size) => {//更新当前页显示的记录
                view_data.curPage = cur_page
                view_data.curproductList = view_data.productListByCate.slice((cur_page - 1) * page_size, cur_page * page_size)
            }

            
            return {                
                ...toRefs(view_data),
                getProductList,            
                handleSizeChange,
                handleCurrentChange,
                createCurGoodList,
                getProductByCate,
                toGiveLike,
                toCollect,
                handlerDownload,
                toDownLoad,
                setProductStatus,
                toSearch,
                // handleUpload,
                // beforeUpload,
                // handleExceed,
                // handleUpAvatar                
           }
       } 
    }
</script>


<style>
    /*2*/
    .page-header{
        width: 100vw;
        height: 14vh;
        background-color: rgb(218, 116, 32);   
        display: flex;
        align-items: flex-end; 
        justify-content: space-between;                                                                 
    }
    .nav-child{
        width: 28vw;
        height: 10vh;
        /* background-color: rgb(117, 185, 163);                              */
    }
    .nav-child-ul{
        width: 400px;
        margin-left: 55px;
    }
    .search{
        height: 10vh;
        width: 25vw;
        margin-right: 90px;        
        line-height: 10vh;
        text-align: center;
        
    }
    .page-content {
        width: 100vw;
        height: 175vh; 
        display: flex;
        flex-direction: column;        
    }
    .menu_product_item:hover  {        
        cursor:pointer;
    }
    .menu_product_item:active  {        
        color:#f3f0e2;
    }
    
    /*3*/
    .page-product-list{
        width: 90vw;
        height: 137vh;
        /* background-color: rgb(77, 99, 92); */
        margin-top: 30px ;
        margin-left: 55px;
        display: flex;
        justify-content: flex-start;
        flex-wrap: wrap;
        
    }
    .page-content .item-card:hover{
        box-shadow: 6px 6px 3px #888888;
        transform: translate(0,-5px);             
    }
    .item-card{
        width: 350px;
        height: 360px;                        
        transition: all 0.6s;   
        border:rgb(215, 215, 215) solid 1px;
        border-radius: 5px;  
        margin-left: 16px;
        margin-right: 16px;
        /* margin-bottom:16px; */

    }
    .item-image{
        position: relative;
        width: 350px;
        height: 250px;                                               
    }
    .mask{
        position: absolute;
        top: 0;
        left: 0;
        width: 350px;
        height: 250px;
        background: rgba(71, 71, 71, 0.6);
        color: #ffffff;
        opacity: 0;
        display: flex;
        justify-content: center;
        flex-direction: column;
        align-items: center;
        border-radius: 0px 5px 0px 5px; 
    }
    .item-image-mask-icon {
        width: 35px;
        height: 30px; 
        margin: 10px; 
        transition: all 0.6s; 
    }
    .mask img:hover{  
        transform: scale(1.1);        
        
    }
    .item-image span:hover .mask{
        opacity:1;
        cursor: pointer;
    }
    .item-text-top{   
        margin: 0px;             
        width: 330px;
        height: 10px;
        background-color: rgb(219, 202, 199);
        padding-top: 30px;
        padding-left: 20px;                            
    }
    .item-text-bottom{
        width: 350px;
        height: 60px;                
        background-color: rgb(219, 202, 199);
        padding-bottom: 10px;
        display: flex;
        justify-content: space-between;                
    } 
    .item-text-name {               
        display: flex;
        text-align: left;            
    }
    .item-text-space{
        width: 180px;           
    }
    .item-text-icon-avatar{
        padding-top: 30px;
        padding-left: 20px;
        margin-right: 5px;

    }
    .item-text-icon-like{ 
        padding-top: 30px;               
        margin-right: 5px;
    }
    .item-text-remark-user{
        padding-top: 30px;                
        display: flex;
        justify-content: center;                
    }
    .item-text-remark-like{
        padding-top: 30px;     
        padding-right: 20px;                   
        display: flex;
        justify-content: center;                
    }

    /*4*/
    .page-more{
        width: 90vw;
        height: 20vh;
        /* background-color: aquamarine; */
        margin: 0px 75px 0px 55px;
        display: flex;
        justify-content: center;
        align-items: center;
        
    }

    .infinite-list {
  height: 300px;
  padding: 0;
  margin: 0;
  list-style: none;
}
.infinite-list .infinite-list-item {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 50px;
  background: var(--el-color-primary-light-9);
  margin: 10px;
  color: var(--el-color-primary);
}
.infinite-list .infinite-list-item + .list-item {
  margin-top: 10px;
}

  
</style>