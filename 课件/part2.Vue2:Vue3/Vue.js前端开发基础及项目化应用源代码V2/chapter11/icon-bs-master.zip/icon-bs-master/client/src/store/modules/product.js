const SET_PRODUCT_BASIC_LIST = 'SET_PRODUCT_BASIC_LIST'

const product = {
    namespaced: true,
    state: {
        product_basic_list: []        
    },
    getters: {        
        productBasicList: state => state.product_basic_list
    },
    mutations: {
        //使用常量来代替函数名称  
        [SET_PRODUCT_BASIC_LIST](state, productBasicList) {
            state.product_basic_list = productBasicList                      
        }
    }
}

export default product