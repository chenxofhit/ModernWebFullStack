<template>
        <div class="page-header">
            <div class="nav-child">
                <ul class="nav-child-ul">
                    <li class="menu_user_item" @click="toUserAccount">我的帐户</li>
                    <li class="menu_user_item" @click="toUserFavorite">我的收藏</li>
                    <li class="menu_user_item" @click="toUserUpload">上传资源</li>                    
                </ul>
            </div>            
        </div>
        
        <div class="page-userinfo"> 
            <component :is="currentComponent"/> 
            <div class="page-content-viewer">
                <div class="viewer-title">
                    推荐
                </div>                    
                <div class="viewer-content">
                    <img class="viewer-minimage" src="../../assets/img/p1.png" />
                    <span class="viewer-minimage-title">传统建筑飞檐设计........</span>
                </div>
                <div class="viwer-border">
    
                </div>
                <div class="viewer-content">
                    <img class="viewer-minimage" src="../../assets/img/p2.png" />
                    <span class="viewer-minimage-title">建筑内部空间设计........</span>
                </div>
            </div>
        </div>

    
</template>
<script>
    import { shallowRef } from 'vue'    
    import UserAccount from '@/views/user/components/UserAccountItem.vue'
    import UserFavorite from '@/views/user/components/UserFavoriteItem.vue'
    import UserUpload from '@/views/user/components/UserUploadItem.vue'
    import { useRouter } from "vue-router"  //引入方法
    export default {
        name: 'UserInfo',
        components: {
           UserAccount,
           UserFavorite,
           UserUpload
        },
        setup() {  
            const router = useRouter()       
            //这里不要使用ref，警告被包装成了响应式的对象，会造成不必要的性能开销，应使用shallowRef
            //shallowRef只处理基本数据类型的响应式, 不进行对象的响应式处理
            //只是替换新的对象，而不进行对象的响应式处理，即不对对象的属性进行修改等操作
            const currentComponent = shallowRef(router.currentRoute.value.query.current) 
            const toUserAccount = () => {
                currentComponent.value = 'UserAccount'
            }
            const toUserFavorite = () => {
                currentComponent.value = 'UserFavorite'
            }
            const toUserUpload = () => {
                currentComponent.value = 'UserUpload'
            }

            return {     
                currentComponent,              
                toUserAccount,
                toUserFavorite,
                toUserUpload
            }
        }
    }
</script>
<style>
    /*2*/
    .page-header{
        width: 100vw;
        height: 14vh;
        background-color: rgb(218, 116, 32);   
        display: flex;
        align-items: flex-end; 
        justify-content: space-between;                                                                 
    }
    .nav-child{
        width: 500px;
        height: 10vh;
        /* background-color: rgb(117, 185, 163);                              */
    }
    .nav-child-ul{
        width: 280px;
        margin-left: 80px;
    }
    .menu_user_item:hover  {        
        cursor:pointer;
    }
    .menu_user_item:active  {        
        color:#f3f0e2;
    }
    /*3*/
    .page-userinfo{
        width: 100vw;
        height: 158vh;
        /* background-color: aquamarine;  */
        margin: 30px 75px 0px 75px;
        display: flex;
        justify-content: space-between;
        flex-wrap: wrap;
    }            
    
    .page-content-viewer {
        width: 300px;
        height: auto;
        /* background-color: darkgoldenrod; */
        margin: 20px 20px 20px 10px;
        border:#281C15 solid 1px;
        border-radius: 5px;
    }
    .viewer-content{
        height: 60px;
        width: 250px;
        display: flex;
        justify-content: space-around;        
        padding-right: 0px;
        padding-left: 15px;
    }
    .viewer-title {
        height: 28px;
        line-height: 20px;
        margin: 20px;        
        border-bottom: #281C15 solid 1px;
    }
    .viewer-minimage{
        width: 78px;
        height: 52px;
        border:rgb(231, 229, 229) solid 1px;
        border-radius: 3px;
        margin-right: 20px;
    }
    .viwer-border {
        margin: 20px;                
        border-bottom: #281C15 solid 1px;
    }
</style>