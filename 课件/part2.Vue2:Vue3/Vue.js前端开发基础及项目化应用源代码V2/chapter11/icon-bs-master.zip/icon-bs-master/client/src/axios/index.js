import axios from 'axios'
import { ElMessage } from 'element-plus'
import router from "../router"  //引入router

const instance = axios.create({
  //baseURL设置用于生产环境下跨域设置的前端参数配置
  baseURL: 'http://127.0.0.1:3000',
  //baseURL:'/',
  timeout: 1000 * 60 * 2
})

// 请求发送前需要处理的内容
instance.interceptors.request.use(
    config => { 
        //加上token      
        config.headers.Authorization = 'Bearer ' + sessionStorage.getItem('token')
        return config
    }, 
    error => {    
        return Promise.reject(error)
})
// //transformRequest在向服务器发送前，修改请求数据
// instance.defaults.transformRequest = [function (data, config) {
//     if (data === undefined || data === null) return null
//     return data
// }]

//response表示服务器端响应，包括header,data,status等
instance.interceptors.response.use(
    response => {
        if(response.status === 200 && response.data.code === 1){
            return response.data.data
        } else {
          //将出错信息以提示框形式反馈给客户
            ElMessage({
                type:'error',
                message: response.data.message,
                duration: 5*1000
            })
            //将出错信息同时返回到console
            return Promise.reject(response.data.message)
        }
}, error => {//当token无效时，返回401，跳转至首页面
    if(error.response && error.response.status === 401) { 
        sessionStorage.removeItem('token')
        router.push('/default')
        ElMessage({
            type: 'warning',
            message: '请先登录'
        })        
    }
})

export function request (options) {
    return instance(options)
}

// 上面的方式将原axios请求方法进行了重写
//new Promise这部分的内容放到拦截器中
//下面是原生axios代码，原生axios请求参数options是一个json对象，含有url, data,method
/* export function promiseRequest (options) {
  return new Promise((resolve, reject) => {
    instance(options).then(res => {
      console.log('返回数据', res)
      resolve(res)
    }).catch(error => {
      console.log(error)
      reject(error)
    })
  })
} */