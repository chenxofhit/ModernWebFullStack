<template>
    <div>
        <span :style="{fontSize: `${size}px`, color:`${color}`}">   
            <slot>Icon</slot>        
        </span>
    </div>
</template>
<script>
    import {toRefs} from 'vue'
    import {Menu} from '@element-plus/icons-vue'
    export default {
        name: 'SysIcon',        
        props: {
            color: {
                type: String,
                default: 'rgb(0,0,0)'
            },       
            size: {
                type: [Number,String],
                default: 30
            }   
        }
    }
</script>