<template>
    <div>
        <span :class="custom" :style="{fontFamily: family, fontSize: `${size}px`}">
            <slot>Content</slot>
        </span> 
    </div>
</template>
<script>
    import {toRefs} from 'vue'
    export default{
        name:'SysText',
        props:{
            custom: {
                type: String,
                default: ''
            },
            family:{
                type: String,
                default: "tahoma,'microsoft yahei'"
            },
            size: {
                type: [Number,String],
                default: 16
            }
        }       
    }
</script>