<template>
    <div class="home">
        <div class="page-top">                
            <div class="logo">
               <div class="logo-pic"></div>        
            </div>
            <div class="nav">
                <ul class="nav-ul">
                    <li>
                        <router-link :to="{name: 'default'}">
                            <span class="menu_item">首页</span>
                        </router-link>
                    </li>                   
                    <li class="menu_product" @click="goProduct" >
                        <span class="menu_item">图片集</span>
                    </li>             
                    <li>
                        <router-link :to= "{name: 'user', query: { current: 'UserAccount'}}">
                            <span class="menu_item">个人中心</span>
                        </router-link>
                    </li>
                    <li>
                        <router-link :to="{name: 'help'}">
                            <span class="menu_item">关于</span>
                        </router-link>
                    </li>
                </ul>
            </div>                            
            <div class="user-info">
                <div class="user-profile">                     
                    <el-dropdown :hide-on-click="false" @command="handleCommand">
                        <span class="el-dropdown-link">
                            <sys-icon size= "23" color="#f3f0e2" v-if='!isLogin'><i class="ri-login-box-line"></i></sys-icon>
                            <sys-icon size="23" color="#f3f0e2" v-if='isLogin'><i class="ri-user-fill"></i></sys-icon>
                        </span>
                        <template #dropdown>
                          <el-dropdown-menu>
                            <el-dropdown-item command="register">注册</el-dropdown-item>
                            <el-dropdown-item command="login">登陆</el-dropdown-item> 
                            <el-dropdown-item command="logout" divided>退出</el-dropdown-item>                            
                          </el-dropdown-menu>
                        </template>
                      </el-dropdown>
                </div>
                <div class="cart-icon">          
                    <sys-icon size="23" color="#f3f0e2"><i class="ri-shopping-cart-line" @click="goFavorites"></i></sys-icon>
                    <span class='icon-car-count' v-if='isLogin'>{{cartCount}}</span>
                </div>               
                <login-dialog :show="loginIsShow" @toShow_login="handleLoginDialog"></login-dialog>
                <register-dialog :show="registerIsShow" @toShow_register="handleRegisterDialog"></register-dialog>                                                             
            </div>
        </div>

        <!--页面主体部分-->
        <router-view></router-view>
        
        
        <div class="page-footer">
            <div class="footer-text">
                <sys-text  custom='text-color' size='12'>用户可以自定义下载多种格式的图片和图标，也可以自行调整颜色和尺寸，便于前端开发应用。
                </sys-text>
                <sys-text  custom='text-color' size='12'>转载内容版权归作者及来源网站所有，本站原创内容转载请注明来源。</sys-text>
                <sys-text  custom='text-color' size='12'>法律声明 隐私协议 粤ICP备012345678号-00 </sys-text>
            </div>         
        </div>
    </div>
</template>
<script>
    import { ref, computed, inject, onMounted } from 'vue' 
    import { useRouter } from "vue-router"  //引入方法
    import { Edit, ArrowDown, ShoppingCart } from '@element-plus/icons-vue'    
    import LoginDialog from "../components/page/LoginForm.vue"
    import RegisterDialog from "../components/page/RegisterForm.vue"
    import { useStore } from 'vuex'
    import { request } from '@/axios'    
    
    export default {
        name:'Home',
        components: {
            LoginDialog,
            RegisterDialog,
            Edit,
            ArrowDown,
            ShoppingCart      
        },     
        setup() {
            const router = useRouter() 
            const store = useStore()    
            
            const loginIsShow = ref(false)   
            const loginStatus = ref(false)       
            const handleLoginDialog = (val) => {
                loginIsShow.value = val
            }            
            const isLogin = computed(() => {                
                let token = sessionStorage.getItem('token')         
                const favoriteCount = store.getters['user/favoriteCount']
                if(token && favoriteCount != -1) {                    
                    loginStatus.value = true
                } else {
                    loginStatus.value = false                    
                }             
                return loginStatus.value
            })
              
            const registerIsShow = ref(false) 
            const handleRegisterDialog = (val) => {
                registerIsShow.value = val
            } 
            
            const handleCommand = (commond) => {
                if(commond === "login") {
                    loginIsShow.value = true
                } 
                if(commond === "logout"){  
                    console.log("logout:")                    
                    store.commit('user/SET_FAVORITE_COUNT', -1)
                    store.commit('product/SET_PRODUCT_BASIC_LIST', [])
                    sessionStorage.setItem('token', '')
                    sessionStorage.setItem('userId', '')
                    router.push({name: 'default'})                   
                }
                if(commond === "register") {
                    registerIsShow.value = true
                } 
            }            
            const cartCount = computed(() => {
                const favoriteCount = store.getters['user/favoriteCount']
                return favoriteCount
            })            
            const goFavorites = () => {                  
                router.push({
                    name: 'user',
                    query: {current: 'UserFavorite'}
                })
            }
            const reload_func = inject('reload')  //注入reload 
            const goProduct = () => {                            
                reload_func()  //图片集更新完成后刷新页面                 
                router.push({name: 'product'})
            }

            return {
                handleCommand,
                handleLoginDialog,                
                loginIsShow,
                registerIsShow,
                handleRegisterDialog,
                cartCount,
                loginStatus,
                isLogin,
                goProduct,
                goFavorites
            }
        }
    }
</script>
<style>
    
    html{/*隐藏横向滚动条*/
        overflow-x: hidden;                
    }       
    ::-webkit-scrollbar {/*滚动条整体样式*/
        width: 5px;
        height: 5px;
       
    }
    ::-webkit-scrollbar-thumb {/*滚动条里面小方块*/
        border-radius:5px;
        box-shadow: inset005pxrgba(0,0,0,0.2);
        background:rgba(241, 243, 228, 0.2);
    }
    body {
        margin: 0;  /*去掉页面边距*/
        font-size: 14px;
        font-family: tahoma,"microsoft yahei" !important;
    }
    .item-font{
        font-size: 12px;
    }
    ul {
        list-style-type: none;
        list-style-image: none;
        margin: 0px; 
        padding:0px;                 
        line-height: 10vh;   
        display: flex;
        justify-content: space-around;
        align-items: center;                        
    }
    
    /*去除router-link 链接下划线 */
    a{
        text-decoration: none;
        color: #000;
    }
    /*设置点击后的样式 */
    .menu_product:hover {
        cursor:pointer;
        
    }  
    .menu_item{
        color: #f3f0e2;
    }
    
    .home{
        width: 100vw;
        height: 218vh;
        background-color: antiquewhite;
        position: absolute;
        display: flex;
        flex-wrap: wrap;
    }
    /*1*/
    .page-top{
        width: 100vw;
        height: 10vh;
        background-color: goldenrod;
        display: flex;
        justify-content: space-between;
    }
    .logo{
        height: 10vh;
        width: 15vw;                   
        align-items:center;         /*垂直居中*/        
        background-color: #281C15;                 
        display: flex;
        justify-content: right;               
    }
    .logo-pic{
        height: 5vh;
        width: 6vw;                 
        background: url("../assets/img/logo11.jpg");        
        background-repeat: no-repeat;
        background-size: 6vw 5vh;
        margin-right: 2px;
    }
    .nav{
        height: 10vh;
        width: 80vw;
        background-color: #282515; 
        padding: 0px 160px 0px 0px;           
    }
    .nav-ul{
        width: 400px;
    }
    .el-dropdown-link {
        cursor: pointer;
        color: var(--el-color-primary);
        display: flex;
        align-items: center;
    }
    .user-info{
        height: 10vh;
        width: 14.5vw;
        background-color: #281C15;
        display: flex;
        justify-content: left;
        align-items:center;         /*垂直居中*/ 
    }
    .user-profile{
        height: 4vh;
        width: 1.8vw;  
        margin-right: 8px;               
        /* background: url("../assets/img/user.jpg");
        background-repeat: no-repeat;
        background-size: 1.8vw 4vh;                 */
    }
    /*购物车上小圆圈样式 */
    .icon-car-count {
        min-width: 24px;  
        text-align: center;
        line-height: 12px;
        display: inline-block;
        position: absolute;    
        top: -5px;
        background: red;
        color: #fff;
        border-radius: 17px;
        padding: 7px;
        font-size: 14px;
        transform: scale(.7);
        font-family: Tahoma!important;
    }
        
    /*4*/
    .page-footer{
        width: 100vw;
        height: 35vh;
        background-color: black;              
    } 
    .footer-text {
        margin-top: 100px;
        height: 90px;         
        display: flex;
        flex-direction: column;
    }
    .text-color{
        color:rgb(112, 109, 109);
        font-weight: 100;
    }
</style>