<template>
    <div>
        <el-dialog v-model="show" title="系统登录" width="540px" @close="toClose">
            <el-form :model="form" ref="loginForm" >
              <el-form-item label="用户名" :label-width="formLabelWidth" prop="userName">
                <el-input :prefix-icon="Avatar" v-model="form.userName" autocomplete="off" class="input-size"></el-input>
              </el-form-item>
              <el-form-item label="密  码" :label-width="formLabelWidth" prop="password">
                <el-input :prefix-icon="Lock" v-model="form.password" autocomplete="off" class="input-size"></el-input>
              </el-form-item>
            </el-form>
            <template #footer>
              <span class="dialog-footer">
                <el-button type="primary" @click="toLogin">登陆</el-button>
                <el-button @click="toCancel">取消</el-button>                
              </span>
            </template>
        </el-dialog>
    </div>
</template>
<script>
import {reactive, toRefs, ref} from 'vue'
import {Avatar, Lock} from '@element-plus/icons-vue'
import { useRouter } from "vue-router"  //引入方法
import { useStore } from 'vuex'
import { request } from '@/axios'
import { ElMessage } from 'element-plus'
export default {
    name: 'LoginDialog',
    props:{
        //子组件属性show
        show: {
            type: Boolean,
            default: false
        }  
    },
    emits:['toShow_login'],
    setup(props, context) {
        const router = useRouter()   //只能在setup()中这样用
        const store = useStore()
        const loginForm = ref(null)
        const dialogTableVisible = ref(false)
        const {show} = toRefs(props)
        const formLabelWidth = '120px'
        const view_data = reactive({
            form:{
              userName: '',
              password: ''
            }            
        })
        const toClose = () => {
          context.emit("toShow_login", false)
        }
        const toLogin = async() => {  
            let user = Object.assign({}, view_data.form) 
            const data = await request({
              url: '/api/user/login', 
              data: user, 
              method: 'post'
            }) 
            if(data != null) {
                //store.commit('user/SET_USERID', data.userId)
                sessionStorage.setItem('token', data.token)
                sessionStorage.setItem('userId', data.userId)
                toClose()     
                store.dispatch('favorites/getFavorites')
                .then(res => {
                    if(res.code === 1) {
                        const store_favorites = store.getters['favorites/favoritesList']
                        store.commit('user/SET_FAVORITE_COUNT', store_favorites.length)  
                    }                    
                })            
            } else {
                ElMessage({
                    type: 'warning',
                    message: '登录失败',
                    duration: 2000
                })
                loginForm.value.resetFields()
            }              
        }
        const toCancel = () => {
          loginForm.value.resetFields()
        }
        return {            
            ...toRefs(view_data),
            loginForm,
            dialogTableVisible,                
            formLabelWidth,
            Avatar,   //前缀图标需要return 
            Lock,
            props,
            router,
            toLogin,
            toCancel,
            toClose
        }
    }
}
</script>
<style>
  .dialog-size{
    width: 500px;
  }
  .input-size{
    width: 300px;
  }
</style>