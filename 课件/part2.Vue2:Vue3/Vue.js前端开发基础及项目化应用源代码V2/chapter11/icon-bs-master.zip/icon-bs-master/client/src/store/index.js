import { createStore } from 'vuex'
import user from './modules/user.js'
import favorites from './modules/favorites.js'
import product from './modules/product.js'

export default createStore({  
  modules: {
    user,
    product,
    favorites
  }
})
