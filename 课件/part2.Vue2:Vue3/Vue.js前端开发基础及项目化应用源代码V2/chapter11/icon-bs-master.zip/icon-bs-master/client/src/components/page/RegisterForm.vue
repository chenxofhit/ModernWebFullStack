<template>
    <div>
        <el-dialog v-model="show"  title="系统注册" width="540px" @close="toClose">
            <el-form :model="form" ref="registerForm" :rules="rules">
              <el-form-item label="用户名" :label-width="formLabelWidth" prop="userName">
                <el-input v-model="form.userName" autocomplete="off" class="input-size"></el-input>
              </el-form-item>
              <el-form-item label="密  码" :label-width="formLabelWidth" prop="password">
                <el-input v-model="form.password" autocomplete="off" class="input-size"></el-input>
              </el-form-item>
              <el-form-item label="邮  箱" :label-width="formLabelWidth" prop="email">
                <el-input v-model="form.email" autocomplete="off" class="input-size"></el-input>
              </el-form-item>
              <el-form-item label="城  市" :label-width="formLabelWidth" prop="city">
                <el-input v-model="form.city" autocomplete="off" class="input-size"></el-input>
              </el-form-item>
              <el-form-item label="帐户状态" :label-width="formLabelWidth" prop="status">
                <el-switch v-model="form.status"></el-switch><el-form-item label="公开/不公开"></el-form-item>
              </el-form-item> 
              <el-form-item label="个人简介" :label-width="formLabelWidth" prop="introduce">
                <el-input v-model="form.introduce" autocomplete="off" class="input-size"></el-input>
              </el-form-item>
            </el-form>
            <template #footer>
              <span class="dialog-footer">
                <el-button type="primary" @click="toRegister">注册</el-button>
                <el-button @click="toCancel">取消</el-button>                
              </span>
            </template>
        </el-dialog>
    </div>
</template>
<script>
import {reactive, toRefs, ref} from 'vue'
import { useRouter } from "vue-router"  //引入方法
import { useStore } from 'vuex'
import { request } from '@/axios'
import { ElMessage } from 'element-plus'
export default {
    name: 'RegisterDialog',
    props:{
        //子组件属性show
        show: {
            type: Boolean,
            default: false
        }  
    },
    emits:['toShow_register'],
    setup(props, context) {
        const router = useRouter()   //只能在setup()中这样用
        const store = useStore()
        const registerForm = ref(null)
        const dialogTableVisible = ref(false)
        const {show} = toRefs(props)
        const formLabelWidth = '120px'
        const view_data = reactive({
            form:{
              userName: '',
              password: '',
              email: '',
              status: false,
              city: '',
              introduce:''
            }            
        })
        const rules = reactive({
            userName: [{
                required: true,
                message: 'Please input user name',
                trigger: 'blur',
            },
            {
                min: 3,
                max: 12,
                message: 'Length should be 3 to 12',
                trigger: 'blur',
            }],
            password: {
                required: true,
                message: 'Please input password',
                trigger: 'blur',
            },
            email: {
                required: true,
                message: 'Please input email',
                trigger: 'blur',
            },
            city: {
                required: true,
                message: 'Please select city',
                trigger: 'blur',
            },
            introduce: {
                required: true,
                message: 'Please input introduce',
                trigger: 'blur',
            }
        })
        const toClose = () => {
          context.emit("toShow_register", false)
        }
        const toRegister = async() => {  
            let user = Object.assign({}, view_data.form) 
            const data = await request({
              url: '/api/user/addUser', 
              data: user, 
              method: 'post'
            }) 
            const msg = data.affectedRows === 1 ? '注册成功':'注册失败'                    
            ElMessage({
                type: 'info',
                message: msg
            }) 
            toClose()                         
        }
        const toCancel = () => {
          registerForm.value.resetFields()
        }
        return {            
            ...toRefs(view_data),
            registerForm,
            rules,
            dialogTableVisible,                
            formLabelWidth,
            props,
            router,
            toRegister,
            toCancel,
            toClose
        }
    }
}
</script>
<style>
  .dialog-size{
    width: 500px;
  }
  .input-size{
    width: 300px;
  }
</style>