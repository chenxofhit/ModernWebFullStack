<template>
    <div class="page-content-main">  
        <el-form 
        :model="descForm" 
        ref="descFormRef" 
        :rules="rules" 
        label-width="120px"
        class="user-accountForm"
        :inline="false" 
        :size="formSize">
            <el-form-item label="选择图片" prop="productImage">
                <el-upload
                    ref="uploadFile"
                    class="avatar-uploader"
                    action=""
                    :show-file-list="false" 
                    :auto-upload="false"
                    :on-change="handleChange" 
                    >
                    <img v-if="imageUrl" :src="imageUrl" class="avatar" />
                    <el-icon v-else class="avatar-uploader-icon"><plus /></el-icon>
                </el-upload>
            </el-form-item>
            <el-form-item label="图片名称" prop="productName">
                <el-input v-model="descForm.productName"></el-input>
            </el-form-item>
            <el-form-item label="所属类别" prop="category">               
                <el-select v-model="descForm.category" placeholder="请选择">
                    <el-option
                      v-for="(value, index) in category_list"
                      :label="value"
                      :key="index"                      
                      :value="value">
                    </el-option>                    
                  </el-select>
            </el-form-item>
            <el-form-item label="产品描述" prop="productDesc">
                <el-input v-model="descForm.productDesc"></el-input>
            </el-form-item>
            <el-form-item>
                <el-button type="primary" @click="toHandleUpload">提交</el-button>
                <el-button>取消</el-button>
            </el-form-item>
        </el-form>        
    </div>
</template>
<script>
    import { Plus } from '@element-plus/icons-vue' 
    import {ref, toRefs, reactive, inject} from 'vue'
    import { ElMessage } from 'element-plus'
    import { useStore } from 'vuex'
    import {request} from '@/axios'
    export default {
        name: 'UserUpload',
        components: {
            Plus
        },
        setup(){            
            const uploadFile = ref()  
            const formSize = ref('default')
            const descFormRef = ref(null) 
            const store = useStore()
            const load_data  = reactive({
                filename:'',  
                fileSize:0,              
                imageUrl:'',
                params:'',
                createDate:'',
                category_list:[],                
                descForm:{  
                    productImage:'',                  
                    productName:'',
                    category:'',
                    productDesc:''
                }
            
            })
            const rules = reactive({ 
                productImage: { 
                    required: true,
                    message: 'Please select product image',
                    trigger: 'blur',
                },               
                productName: { 
                    required: true,
                    message: 'Please input product name',
                    trigger: 'blur',
                },
                category: {
                    required: true,
                    message: 'Please select category',
                    trigger: 'change',
                },
                productDesc: {
                    required: true,
                    message: 'Please input product description',
                    trigger: 'blur',
                }
            })

            load_data.category_list = inject('$category')

            //处理表单上传
            const toHandleUpload = async(params) => {
                let isValide = false
                await (descFormRef.value).validate((valide) => {
                    if(valide){
                        isValide = true
                    } else {
                        ElMessage.error('表单数据无效')                        
                    }
                })
                if(isValide) {                    
                    getDate();//获取日期数据给load_data.createDate
                    let desc_form = Object.assign({}, load_data.descForm)  
                    load_data.params.append("productName", desc_form.productName)
                    load_data.params.append("category", desc_form.category)
                    load_data.params.append("productDesc", desc_form.productDesc)                    
                    load_data.params.append("fileName", load_data.filename)
                    load_data.params.append("fileSize", load_data.fileSize)
                    load_data.params.append("userId", sessionStorage.getItem("userId"))//store.getters['user/userId'])
                    load_data.params.append("createDate", load_data.createDate)      
                    
                    
                    const data = await request({
                        url:'/api/product/addProduct', 
                        data: load_data.params, 
                        processData: false,
                        contentType: false,
                        method: 'post'}) 
                    
                    const msg = data.affectedRows === 1 ? '新增成功':'新增失败'                    
                    ElMessage({
                        type: 'info',
                        message: msg
                    }) 
                    //更新store中的产品列表
                    if(data.affectedRows === 1) {
                        const picList = await request({
                            url: '/api/product/getAllProduct',
                            method:'get'
                        })
                        if(picList) {
                            store.commit('product/SET_PRODUCT_BASIC_LIST', picList)        
                        }  
                    }
                }
            }

            const getDate = ()=>{
                var time = new Date()            
                var y = time.getFullYear()    //年
                var m = (time.getMonth() + 1).toString().padStart(2, '0')  //月
                var d = time.getDate().toString().padStart(2, '0')    //日
                var h = time.getHours().toString().padStart(2, '0')    //时
                var mm = time.getMinutes().toString().padStart(2, '0')   //分
                var s = time.getSeconds().toString().padStart(2, '0')     //秒
            
                load_data.createDate = `${y}-${m}-${d}`
            }
            
            //上传文件状态改变时的处理，包括改变、上传成功或失败
            const handleChange = (file, fileList) => {
                const type = ['image/jpeg', 'image/jpg', 'image/png']
                if (type.indexOf(file.raw.type) === -1) {
                    ElMessage.error('上传的文件必须是JPG、JPEG、PNG三种之一!')
                    return false
                } else if (file.size / 1024 / 1024 > 8) {
                    ElMessage.error('图片大小不能超过8MB!')
                    return false
                }
                load_data.descForm.productImage = file.raw
                //创建临时的路径来展示图片                
                let URL = window.URL || window.webkitURL
                load_data.filename = file.name
                load_data.imageUrl = URL.createObjectURL(file.raw);
                load_data.fileSize = file.size
                //创建FormData获取文件对象
                load_data.params = new FormData()
                load_data.params.append('file', file.raw)
            }

            return {
                uploadFile,
                descFormRef,
                formSize,
                rules,                
                ...toRefs(load_data),
                getDate,
                handleChange,
                toHandleUpload
            }
        }
        
    }
</script>

<style>
    .avatar-uploader .el-upload {
        border: 1px dashed #d9d9d9;
        border-radius: 6px;
        cursor: pointer;
        position: relative;
        overflow: hidden;
    }
    .avatar-uploader .el-upload:hover {
        border-color: #115fad;
    }
    .avatar-uploader-icon {
        font-size: 28px;
        color: #43474d;
        width: 178px;
        height: 178px;
        text-align: center;
    }
    .avatar {
        width: 178px;
        height: 178px;
        display: block;
    }
</style>