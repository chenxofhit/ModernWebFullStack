module.exports = {
    publicPath: '/', //publicPath: '/icon/', 
    outputDir: 'dist',
    assetsDir: 'assets',
    lintOnSave: false,
    devServer: {
        open: false,//是否自动 开启浏览器
        host: 'localhost',
        port: 8090,
        // https: false,
        // hotOnly: false,
        //开发模式下的跨域设置 
        // proxy: {
        //     'api/': {
        //         target: 'http://localhost:3000/api/',
        //         ws: true,
        //         changeOrigin: true,
        //         pathRewrite: {
        //             '^/api': ''
        //         }
        //     }
        // }
    }
    
} 